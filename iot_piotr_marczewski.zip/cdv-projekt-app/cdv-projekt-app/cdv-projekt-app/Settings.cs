﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cdv_projekt_app
{
    public class Settings
    {
        public static string Url = "https://cdv-projekt.azurewebsites.net/api";
    }
}
