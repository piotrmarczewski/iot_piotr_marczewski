﻿namespace cdv_projekt_app.Models
{
    internal class Login
    {
        public Login()
        {
        }

        public string email { get; set; }
        public string password { get; set; }
    }
}